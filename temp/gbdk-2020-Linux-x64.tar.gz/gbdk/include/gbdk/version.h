#ifndef __VERSION_H_INCLUDE__
#define __VERSION_H_INCLUDE__

#define __GBDK_VERSION 406

#endif
