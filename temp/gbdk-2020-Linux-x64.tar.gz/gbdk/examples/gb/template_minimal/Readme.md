
An minimal template project with a Makefile that only compiles files in the same directory

The Makefile will automatically detect and compile new source files as long 
as they are placed in the same directory as the Makefile


